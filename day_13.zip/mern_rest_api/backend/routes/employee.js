const express = require('express');


const { createEmployee , getAllEmployees , editEmployee, deleteEmployee, findEmployee} = require('../controllers/employeeController');

const router = express.Router();

router.post("/",createEmployee)
router.get("/",getAllEmployees)
router.put("/:id",editEmployee)
router.delete("/:id",deleteEmployee)
router.get("/:id",findEmployee)

module.exports = router;