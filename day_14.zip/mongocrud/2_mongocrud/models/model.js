const mongose = require('mongoose');

const pirateSchema  =  new mongose.Schema({
    id:Number,
    name:String,
    age:Number,
    bounty:Number,
    status:String
})


const pirateMdle = mongose.model('piratemdle',pirateSchema);
module.exports = pirateMdle;