const express = require('express');
const bodyParser = require('body-parser');
const exhbs = require('express-handlebars');
const dbo = require('./dbs.js');
const app = express();
const pirateModel = require('./models/model.js');

dbo.getDatabase();

app.engine('hbs',
    exhbs.engine({
        layoutsDir:'mains',
        defaultLayout:'main',
        extname:'hbs',

        runtimeOptions: {
            allowProtoPropertiesByDefault: true,
            allowProtoMethodsByDefault: true,
          },
    
    
    }));
    

app.set('view engine', 'hbs');
app.set('views', 'mains');
app.use(bodyParser.urlencoded({extended: true}));


app.post('/pirateinfo', async (req, res) => {
    const pirate = {
        id: req.body.id,
        name: req.body.name,
        age: req.body.age,
        bounty: req.body.bounty,
        status: req.body.status
    };

    const pirateDoc = new pirateModel(pirate);
    await pirateDoc.save();

    

    res.redirect('/?status=1');
});



app.get('/',async(req,res) =>{
    let msg = 'Please Insert the valid Details..';
    let pirates = [];
    let edit_id = '';
    let edit_pirates ='';
    
    if(req.query.edit_man){
        edit_id = req.query.edit_man;
        edit_pirates = await pirateModel.findOne({_id:edit_id});
    }

    if(req.query.delete_man){
        delete_id = req.query.delete_man;
        console.log('Delete request for the id: ',delete_id);
        await pirateModel.deleteOne({ _id:delete_id });
        res.redirect('/?status=3')
    }

    if(req.query.status === '1'){
        msg = 'Data Inserted Successfully';
    }
    if(req.query.status === '3'){
        msg = 'Data Deleted Successfully';
    } 

    pirates = await pirateModel.find({});

    res.render('main', {msg,pirates,parsed_id:edit_id,edit_pirates});
})


app.listen(8008, () =>{
    console.log('Listening on port 8002...');
        console.log('Server is running...');
})



