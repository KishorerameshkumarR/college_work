const mongose = require('mongoose');

async function getDatabase() {


  
  mongose.connect('mongodb://localhost:27017/t1')
    .then(() => {
      console.log('Connected to MongoDB');
    })  
    .catch((error) => { 
      console.error('Error connecting to MongoDB:', error); 
    });
}

module.exports = {
  getDatabase
}