const mongose = require('mongoose');
const  empSchema = new mongose.Schema({
    empid: Number,
    empname: String
})

const empMdle = mongose.model('empmdle',empSchema);
module.exports = empMdle;