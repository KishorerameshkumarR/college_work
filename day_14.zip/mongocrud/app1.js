const express = require('express');
const bodyParser = require('body-parser');
const exhbs = require('express-handlebars');

app.engine('hbs',
    exhbs.engine({
        layoutsDir:'viewsfold',
        defaultLayout:'main',
        extname:'hbs'}));

        


app.set('view engine', 'hbs');
app.set('views', 'viewsfold');
app.use(bodyParser.urlencoded({extended: true}));