const mongodb = require('mongodb');
const mongoClient = mongodb.MongoClient;

function getDatabase() {
    if (!database) {
        const client =  mongoClient.connect(url);
        database = client.db('t1');
        console.log('Connected to database');
    }
    return database;
}

module.exports = { getDatabase}