const mongodb = require('mongodb');
const mongoClient = mongodb.MongoClient;

{/* import {MongoClient} from 'mongodb'; */}

const url = 'mongodb://localhost:27017';
let database;
const objectId = mongodb.ObjectId;


async function getDatabase(){
    const client = await mongoClient.connect(url);

    database = client.db('t1');
    if(database){
        console.log('Connected to database');
    }
    else{
        console.error('Database connection failed');
    }

    return database;

}

module.exports = {getDatabase,objectId};