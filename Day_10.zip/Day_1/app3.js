const express = require('express')
const bodyParser = require('body-parser')
const exhbs = require('express-handlebars')

const app2 = express()

app2.engine('hbs',
    exhbs.engine({
        layoutsDir:'viewsfold',
        defaultLayout:'maincopy',
        extname:'hbs'}));
    

app2.set('view engine', 'hbs');
app2.set('views', 'viewsfold');




app2.get('/', (req, res) => {
    const msg = 'OIIOAIIOAIOOAIIAII'
    res.render('maincopy', { msg });
})

app2.listen(2000, () => {
    console.log('Server is running on port 2000')
    for(let i=0; i<5; i++){
        console.log('Server is running...');
    }
})


